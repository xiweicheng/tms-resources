export default [{
    label: '待规划',
    value: '待规划',
    color: 'orange',
    type: 'tag'
}, {
    label: '待处理',
    value: '待处理',
    color: 'green',
    type: 'tag'
}, {
    label: '进行中',
    value: '进行中',
    color: 'yellow',
    type: 'tag'
}, {
    label: '已完成',
    value: '已完成',
    color: 'blue',
    type: 'tag'
}, {
    label: '已验收',
    value: '已验收',
    color: 'grey',
    type: 'tag'
}];
