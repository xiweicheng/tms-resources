window.nsCtx = {
    loginUser: {},
    isSuper: false,
    isAdmin: false,
    users: [],
    channels: [],
    memberAll: {
        username: 'all',
        enabled: true,
        mails: '',
        name: '全员'
    },
    isAt: true, // is channel or user chat
    chatTo: null, // chat to channel name or username
    chatId: null, // chat to channel name or @username 
    isSuper: false,
    isAdmin: false,
    blogId: null,
    isModaalOpening: false,
    isRightSidebarShow: false,
}
