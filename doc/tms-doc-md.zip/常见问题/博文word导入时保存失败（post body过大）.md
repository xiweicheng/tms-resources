因为tomcat默认支持的最大post请求body是2M，需要按需扩大最大限制。

可以设置`server.xml`中`connector`标签的属性`maxPostSize`     

tomcat：默认大小`2097152`（2M), 例如可以修改设置`maxPostSize="20971520"`时，设置为20M


参考：
- tomcat8 maxPostSize="0" 不生效: https://blog.csdn.net/u013350170/article/details/54963631
- 关于tomcat不同版本的maxPostSize配置差异: https://www.jianshu.com/p/2d7b489940ef