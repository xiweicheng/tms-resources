## 源码仓库

服务后端: https://gitee.com/xiweicheng/tms.git  
沟通&博文前端: https://gitee.com/xiweicheng/tms-frontend.git  
着陆页前端: https://gitee.com/xiweicheng/tms-landing.git  

## 从源码部署后端服务
**前提需要:**
- git 
- maven
- jdk8
- tomcat8
- mysql5.6


## 从源码部署前端服务
**前提需要:**
- git 
- nodejs
- aurelia-cli
- nginx

---

## 直接部署打好的部署war包(推荐此种方式, 源码编译安装需要编译环境,比较费事)

#### 前提需要

- jdk8
- tomcat8
- mysql(推荐5.6,其他版本未很好测试过, 5.7存在已知问题,暂请勿用)

#### mysql准备

**创建数据库**

```
CREATE DATABASE ${db_name} DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
```
${db_name} 替换为想设定的数据库名称.  

> **可选配置** : 如果 **沟通消息&博文** 要支持宽字节字符(例如emoji表情字符), 需要手动修改表结构的`content`字段为`utf8mb4`编码.
一般修改四个表(表会在web服务初次启动完成后通实体映射自动生成)就应该可以了:
![输入图片说明](https://git.oschina.net/uploads/images/2017/0607/140931_b36f6caa_19723.png "在这里输入图片标题")



#### tomcat war包部署
这里下载war包(新版本不再提供war包,需要自行maven打包): http://git.oschina.net/xiweicheng/tms/releases

> 补充: [TMS后端代码](https://git.oschina.net/xiweicheng/tms.git)已经包含了前端的build资源, 所以前端代码无需打包构建.
> 直接基于后端代码进行maven打包即可. 打包命令 `mvn clean package -Dmaven.test.skip=true`


将war包解压到tomcat的**webapps/ROOT/**下面(解压前清空ROOT目录下内容).
> ps: war解压命令 `jar -xvf tms-xxx.war`, 或者通过其他解压缩工具.

### 配置文件修改
**配置位置:** `webapps\ROOT\WEB-INF\classes`
- application.properties修改 `spring.profiles.active=dev` 为 `spring.profiles.active=prod`, 从而使用生产环境配置.
- application-prod.properties修改

**数据库连接信息配置(替换下面配置中的${}为实际配置信息)**

```
spring.datasource.url=jdbc:mysql://${ip}:${port}/${db_name}?useUnicode=true&characterEncoding=UTF-8
spring.datasource.username=${db_username}
spring.datasource.password=${db_password}
```

## Markdown to pdf服务配置
> 该服务是在将博文 **导出为pdf** 需要, 不配置该服务, 不会影响服务的运行, 只是 **导出为pdf** 无法正常使用.

FYI: [tms md2pdf服务模块部署安装](https://gitee.com/xiweicheng/tms/wikis/TMS-md2pdf%E6%9C%8D%E5%8A%A1%E6%A8%A1%E5%9D%97%E9%83%A8%E7%BD%B2%E5%AE%89%E8%A3%85%EF%BC%88%E5%8D%9A%E6%96%87%E5%AF%BC%E5%87%BAPDF%EF%BC%89?sort_id=432950)

## 注意事项
- 系统附件
上传的附件信息在 `webapps\ROOT\upload\` 目录中, 请注意不要误删除. 如果需要备份, 直接备份整个该upload目录即可.
- 数据库备份
请自行拟定备份方案
- 内置管理用户

```
super/88888888  系统管理员, 拥有全部系统权限.
```

- 博文下载pdf
该功能需要服务端配置**md2pdf**服务支持(是一个nodejs模块), 调用路径配置在`application-prod.properties`中, 为: `tms.blog.md2pdf.path=/home/tms/md2pdf`, 可以根据模块位置自行调整配置.

