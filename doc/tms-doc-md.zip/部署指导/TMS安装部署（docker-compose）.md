> 注意：下面docker方式部署因为数据没有映射到外部宿主机上或者其它存储外设上，重新构建应用或者DB镜像后部署，数据会丢失（因此仅适合尝鲜或者演示场景）。若要生产部署请选择[**传统部署方式**](https://gitee.com/xiweicheng/tms/wikis/TMS%E5%AE%89%E8%A3%85%E9%83%A8%E7%BD%B2%EF%BC%88%E4%BC%A0%E7%BB%9F%E6%96%B9%E5%BC%8F%EF%BC%89?sort_id=21982)，或者自行优化调整docker部署参数以保证数据安全。

## 依赖服务
- docker
- docker-compose
- maven
- jdk8

## 依赖镜像
```
docker pull mysql:5.6
docker pull tomcat:8.5
```

## 打tomcat war包

1. 下载源码（下载地址：https://gitee.com/xiweicheng/tms）
2. 修改 `src/main/resources/application.properties`
```
spring.profiles.active=prod
```

3. 修改 `src/main/resources/application-prod.properties`
> 注意使用下面配置，不要做任何调整，否则会报错起不来
```
spring.datasource.url=jdbc:mysql://db:3306/tms?useUnicode=true&characterEncoding=UTF-8
spring.datasource.username=root
spring.datasource.password=pingan
```
4. maven打包（注意选择jdk1.8）

tms项目根目录下执行:
```
mvn clean package -Dmaven.test.skip=true
```
## tomcat镜像制作

tms项目根目录下执行:
```
docker build -t xiwc/tms .
```

## mysql镜像制作

cd到db目录下执行:

```
docker build -t xiwc/tms-mysql .
```

## docker-compose启动服务

```
docker-compose up -d
```

## 服务访问

访问：http://localhost:8090/#/home  
登录密码：`super/88888888` 

> 注意：如果是云主机或者其他物理机，注意端口是否开放，不然访问不了。


Done, enjoy!