## kkFileView部署（单独部署即可）

> 参考：https://kkfileview.keking.cn/zh-cn/docs/production.html

## TMS配置

> 修改配置路径：`src/main/resources/application-prod.properties`  
> 注意：开发环境配置到 `src/main/resources/application-dev.properties`  
> 修改下面配置，属性值为kkFileView服务的地址（例如：http://127.0.0.1:8012）

```
tms.file.online.view.url=
```

配置完成，服务重启即可。
